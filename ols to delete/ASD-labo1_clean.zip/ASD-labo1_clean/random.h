/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   random.h
 * Author: James
 *
 * Created on 25. février 2017, 15:51
 */

#ifndef RANDOM_H
#define RANDOM_H

using namespace std;

int generateurAleatoire(const int max, const int min = 0);

#endif /* RANDOM_H */

