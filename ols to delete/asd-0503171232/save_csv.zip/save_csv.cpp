/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
#include <fstream>
#include "save_csv.h"

void save_in_csv (vector<unsigned> v, string name_file){
   ofstream my_file;
   my_file.open(name_file);
   for(unsigned i: v){
      my_file << i << ";";
   }
   my_file << endl;
   my_file.close();
}

