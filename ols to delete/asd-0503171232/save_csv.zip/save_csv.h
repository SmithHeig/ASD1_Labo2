/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   save_csv.h
 * Author: James
 *
 * Created on 2. mars 2017, 11:31
 */

#ifndef SAVE_CSV_H
#define SAVE_CSV_H

#include <cstdlib>
#include <string>
#include <vector>

using namespace std;

void save_in_csv (vector<unsigned> v, string name_file);

#endif /* SAVE_CSV_H */

